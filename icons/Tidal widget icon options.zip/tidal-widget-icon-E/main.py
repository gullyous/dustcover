"""
main.py
-------
Entry point. Creates the Qt app, the SMTC worker, and the widget, then wires
them together. Run via run.bat (or `python main.py`).
"""

import sys

from PySide6.QtWidgets import QApplication

import config
import icons
from media_backend import MediaWorker
from widget import NowPlayingWidget


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Tidal Now Playing")
    # Brand the running process: tray, taskbar and alt-tab all show the "E"
    # mark even before the app is packaged into a .exe. (The packaged build
    # also gets it from icon.ico via the PyInstaller .spec.)
    app.setWindowIcon(icons.app_icon(config.ACCENT))
    # The widget can be hidden to the system tray, so don't quit just because
    # no window is visible; quitting happens explicitly via the tray/menu.
    app.setQuitOnLastWindowClosed(False)

    widget = NowPlayingWidget()
    worker = MediaWorker()

    # backend -> UI
    worker.updated.connect(widget.on_update)
    # UI -> backend
    widget.playpause_clicked.connect(worker.play_pause)
    widget.next_clicked.connect(worker.next_track)
    widget.prev_clicked.connect(worker.prev_track)
    # lifecycle
    widget.quit_requested.connect(app.quit)
    app.aboutToQuit.connect(worker.stop)

    worker.start()
    widget.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
